import styled from "styled-components";

export const Header = () => {
  return (
    <HeaderWrapper>

    </HeaderWrapper>
  )
}

const HeaderWrapper = styled.div`
  
`